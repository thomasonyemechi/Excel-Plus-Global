<?php
  // error_reporting(0);
    
	include("includes/connection.php");
	$id = $_SESSION['user_id']??'';
	
?>
