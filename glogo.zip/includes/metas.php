 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Links of CSS files -->
 <link rel="stylesheet" href="asets/css/bootstrap.min.css">
 <link rel="stylesheet" href="asets/css/flaticon.css">
 <link rel="stylesheet" href="asets/css/animate.min.css">
 <link rel="stylesheet" href="asets/css/owl.carousel.min.css">
 <link rel="stylesheet" href="asets/css/boxicons.min.css">
 <link rel="stylesheet" href="asets/css/meanmenu.min.css">
 <link rel="stylesheet" href="asets/css/nice-select.min.css">
 <link rel="stylesheet" href="asets/css/fancybox.min.css">
 <link rel="stylesheet" href="asets/css/odometer.min.css">
 <link rel="stylesheet" href="asets/css/magnific-popup.min.css">
 <link rel="stylesheet" href="asets/css/style.css">
 <link rel="stylesheet" href="asets/css/responsive.css">
 <link rel="icon" type="image/png" href="assets/img/favicon.png">