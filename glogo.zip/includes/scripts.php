        <div class="go-top"><i class='bx bx-up-arrow-alt'></i></div>

        <!-- Links of JS files -->
        <script src="asets/js/jquery.min.js"></script>
        <script src="asets/js/popper.min.js"></script>
        <script src="asets/js/bootstrap.min.js"></script>
        <script src="asets/js/fontawesome-all.js"></script>
        <script src="asets/js/appear.min.js"></script>
        <script src="asets/js/odometer.min.js"></script>
        <script src="asets/js/magnific-popup.min.js"></script>
        <script src="asets/js/fancybox.min.js"></script>
        <script src="asets/js/owl.carousel.min.js"></script>
        <script src="asets/js/meanmenu.min.js"></script>
        <!--<script src="asets/js/nice-select.min.js"></script>-->
        <script src="asets/js/sticky-sidebar.min.js"></script>
        <script src="asets/js/wow.min.js"></script>
        <script src="asets/js/form-validator.min.js"></script>
        <script src="asets/js/contact-form-script.js"></script>
        <script src="asets/js/ajaxchimp.min.js"></script>
        <script src="asets/js/main.js"></script>
