<footer class="main-footer">
      <strong>Copyright &copy; <?php echo date('Y') ?></strong>  All rights reserved.
      <div class="float-right d-none d-sm-inline-block">
        <!-- <b><a href="#">Privacy</a> | <a href="#">Terms and Conditions</a></b> -->
      </div>
</footer>