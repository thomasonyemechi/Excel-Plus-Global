<?php
include ("constant.php"); 
include ("functions.php");  
include ("classx.php");	
?>